1- Sperry et al. (1988) - the classic paper on the method we are using to measure hydraulic conductivity.

2 - Melcher et al. (2014) - new review and best practice guidance on methods for measuring hydraulic conductivity.

3 - Cochard (20??) - Instructions for measurements with the XylEm apparatus.

4 - Cochard (2013) - XylEm plus instruction manual.

5 - Cochard et al. (2013) - recent review on methods for measuring xylem vulnerability curves.

6 - Choat et al. (2013) - very influential paper on global patterns of plant vulnerability to drought.

7 - 
Gleason et al. (2016) - very recent paper on the stability-efficiency-tradeoff.
